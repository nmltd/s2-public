package ramo.klevis

class NeuralNetwork {

}
